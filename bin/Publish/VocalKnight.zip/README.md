﻿# VocalKnight

A Hollow Knight mod that takes speech input and performs in game actions based on keywords
